import React, { useState, useEffect } from "react";

interface EmployeeFormProps {
  onSave: (newEmployee: { name: string }) => void;
  selectedEmployee: { id: number; name: string } | null;
}

const EmployeeForm: React.FC<EmployeeFormProps> = ({ onSave, selectedEmployee }) => {
  const [name, setName] = useState<string>(selectedEmployee?.name || "");

  useEffect(() => {
    if (selectedEmployee) {
      setName(selectedEmployee.name); // Pre-fill the form with the selected employee's name
    } else {
      setName(""); // Reset form when no employee is selected
    }
  }, [selectedEmployee]);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (name.trim()) {
      onSave({ name }); // Pass the new/edited employee back to parent
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Enter employee name"
        required
      />
      <button type="submit">{selectedEmployee ? "Edit" : "Save"}</button>
    </form>
  );
};

export default EmployeeForm;
