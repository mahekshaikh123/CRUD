import React, { useState, useEffect } from "react";
import EmployeeList from "./components/EmployeeList";
import EmployeeForm from "./components/EmployeeForm";

const App = () => {
  const [employees, setEmployees] = useState<{ id: number; name: string }[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<{ id: number; name: string } | null>(null);

  // Fetch employees (mock function, replace with real API call)
  const fetchEmployees = () => {
    // Mock employees
    setEmployees([
      { id: 1, name: "mahek shaikh" },
      { id: 2, name: "Rose Smith" },
    ]);
  };

  // Fetch employees on initial load
  useEffect(() => {
    fetchEmployees();
  }, []);

  // Handle save (add new or edit existing employee)
  const handleSave = (newEmployee: { name: string }) => {
    if (selectedEmployee) {
      // Edit existing employee
      setEmployees(employees.map((emp) =>
        emp.id === selectedEmployee.id ? { ...emp, name: newEmployee.name } : emp
      ));
    } else {
      // Add new employee
      setEmployees([
        ...employees,
        { id: Date.now(), name: newEmployee.name },
      ]);
    }
    setSelectedEmployee(null); // Clear the form after save
  };

  // Handle delete employee
  const handleDelete = (id: number) => {
    setEmployees(employees.filter((emp) => emp.id !== id));
  };

  return (
    <div>
      <EmployeeForm onSave={handleSave} selectedEmployee={selectedEmployee} />
      <EmployeeList
        employees={employees}
        onSelect={setSelectedEmployee} // Set selected employee for editing
        onDelete={handleDelete} // Delete employee
      />
    </div>
  );
};

export default App;
