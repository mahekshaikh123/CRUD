import { Request, Response } from "express";
import Employee from "../models/Employee";

export const createEmployee = async (req: Request, res: Response) => {
  try {
    const employee = await Employee.create(req.body);
    res.status(201).json(employee);
  } catch (error) {
    res.status(400).json({ error: "Unable to create employee" });
  }
};

export const getEmployees = async (req: Request, res: Response) => {
  const employees = await Employee.findAll({ where: { isActive: true } });
  res.json(employees);
};

export const getEmployee = async (req: Request, res: Response) => {
  const employee = await Employee.findByPk(req.params.id);
  res.json(employee);
};

export const updateEmployee = async (req: Request, res: Response) => {
  await Employee.update(req.body, { where: { id: req.params.id } });
  res.json({ message: "Employee updated" });
};

export const deleteEmployee = async (req: Request, res: Response) => {
  await Employee.update({ isActive: false }, { where: { id: req.params.id } });
  res.json({ message: "Employee soft deleted" });
};
